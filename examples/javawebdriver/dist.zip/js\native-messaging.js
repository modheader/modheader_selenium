exportFunction((function(e,n){chrome.runtime.sendMessage(e).then((e=>{n(JSON.stringify(e));})).catch((e=>{n(JSON.stringify(e));}));}),window,{defineAs:"sendModHeaderMessage"});
