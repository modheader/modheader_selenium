import { K as Kt, J as Jt, b as a, I as It, a1 as q, B, G as Gt, N, a as t, M as Mt, O as Ot, H as Ht, R, T } from '../storage-writer-d33f2334.js';
import { H as HR } from '../App-4fbc9f45.js';
import { l as Oe } from '../csp-23eae0cd.js';
import { A as Ad } from '../profile-hook-6ccf7046.js';

function u(t){let r;return {c(){r=T("style"),r.textContent="body {\r\n      height: 500px;\r\n      /** Fix FF popup disappearance on long window. */\r\n      width: 620px !important;\r\n    }\r\n\r\n    :root {\r\n      --drawer-width: 36px;\r\n      --app-content-width: calc(100% - 40px);\r\n      --top-bar-width: calc(100% - 35px);\r\n      --top-bar-height: 48px;\r\n    }";},m(t,n){N(t,r,n);},d(t){t&&R(r);}}}function g(t){let r;return {c(){r=T("style"),r.textContent="body {\r\n      height: 100vh;\r\n      width: 100% !important;\r\n    }\r\n    :root {\r\n      --drawer-width: 36px;\r\n      --app-content-width: calc(100% - 40px);\r\n      --top-bar-width: calc(100% - 35px);\r\n      --top-bar-height: 48px;\r\n    }";},m(t,n){N(t,r,n);},d(t){t&&R(r);}}}function b(t$1){let r,n,f,x;r=new HR({});let b=(Oe?g:u)();return {c(){It(r.$$.fragment),n=q(),b.c(),f=B();},m(t,a){Gt(r,t,a),N(t,n,a),b.m(t,a),N(t,f,a),x=!0;},p:t,i(t){x||(Mt(r.$$.fragment,t),x=!0);},o(t){Ot(r.$$.fragment,t),x=!1;},d(t){Ht(r,t),t&&R(n),b.d(t),t&&R(f);}}}Ad();const $=new class extends Kt{constructor(t){super(),Jt(this,t,null,b,a,{});}}({target:document.body});

export { $ as default };
