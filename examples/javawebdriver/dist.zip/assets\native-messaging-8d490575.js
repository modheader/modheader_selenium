(function () {
	'use strict';

	const importPath = /*@__PURE__*/ JSON.parse('"../js/native-messaging.js"');

	import(chrome.runtime.getURL(importPath));

})();
